-- ============================================================
-- INTERVIA — Script SQL complet pour Supabase
-- Copiez-collez ce script dans Supabase > SQL Editor > New query
-- Cliquez sur "Run" pour créer toute la base de données
-- ============================================================

-- Séquence pour les IDs de missions
CREATE SEQUENCE IF NOT EXISTS mission_seq START 1;

-- ── AGENCES ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS agencies (
  id         UUID        DEFAULT gen_random_uuid() PRIMARY KEY,
  name       TEXT        NOT NULL,
  email      TEXT,
  phone      TEXT,
  address    TEXT,
  logo_url   TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── UTILISATEURS ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id         UUID        DEFAULT gen_random_uuid() PRIMARY KEY,
  clerk_id   TEXT        UNIQUE NOT NULL,
  email      TEXT        NOT NULL,
  name       TEXT,
  role       TEXT        DEFAULT 'agency' CHECK (role IN ('agency', 'artisan', 'admin')),
  agency_id  UUID        REFERENCES agencies(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── CATÉGORIES ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS categories (
  id        UUID    DEFAULT gen_random_uuid() PRIMARY KEY,
  name      TEXT    NOT NULL,
  icon      TEXT,
  color     TEXT,
  is_urgent BOOLEAN DEFAULT false
);

-- ── MISSIONS ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS missions (
  id              TEXT        PRIMARY KEY DEFAULT 'M-' || TO_CHAR(NOW(), 'YYYY') || '-' || LPAD(nextval('mission_seq')::TEXT, 4, '0'),
  agency_id       UUID        REFERENCES agencies(id)   ON DELETE SET NULL,
  category_id     UUID        REFERENCES categories(id) ON DELETE SET NULL,
  subcategory     TEXT,
  description     TEXT,
  address         TEXT        NOT NULL,
  contact_name    TEXT,
  contact_phone   TEXT,
  priority        TEXT        DEFAULT 'normal'  CHECK (priority  IN ('normal', 'urgent')),
  status          TEXT        DEFAULT 'Nouveau' CHECK (status IN ('Nouveau', 'En cours', 'Devis envoyé', 'Planifié', 'Terminé', 'Annulé')),
  technician_id   UUID        REFERENCES users(id)      ON DELETE SET NULL,
  scheduled_at    TIMESTAMPTZ,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── PIÈCES JOINTES ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS attachments (
  id          UUID        DEFAULT gen_random_uuid() PRIMARY KEY,
  mission_id  TEXT        REFERENCES missions(id)  ON DELETE CASCADE,
  url         TEXT        NOT NULL,
  name        TEXT,
  type        TEXT        DEFAULT 'photo',
  uploaded_by UUID        REFERENCES users(id)     ON DELETE SET NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── DEVIS ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS quotes (
  id                   UUID        DEFAULT gen_random_uuid() PRIMARY KEY,
  mission_id           TEXT        REFERENCES missions(id)  ON DELETE CASCADE,
  number               TEXT        UNIQUE NOT NULL,
  status               TEXT        DEFAULT 'draft' CHECK (status IN ('draft', 'sent', 'accepted', 'refused')),
  lines                JSONB       DEFAULT '[]',
  total_ht             DECIMAL(10,2) DEFAULT 0,
  total_tva            DECIMAL(10,2) DEFAULT 0,
  total_ttc            DECIMAL(10,2) DEFAULT 0,
  notes                TEXT,
  valid_until          DATE,
  client_signature     TEXT,
  technician_signature TEXT,
  signed_at            TIMESTAMPTZ,
  created_at           TIMESTAMPTZ DEFAULT NOW()
);

-- ── FACTURES ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS invoices (
  id         UUID        DEFAULT gen_random_uuid() PRIMARY KEY,
  mission_id TEXT        REFERENCES missions(id)  ON DELETE CASCADE,
  quote_id   UUID        REFERENCES quotes(id)    ON DELETE SET NULL,
  number     TEXT        UNIQUE NOT NULL,
  status     TEXT        DEFAULT 'draft' CHECK (status IN ('draft', 'sent', 'unpaid', 'paid', 'overdue')),
  lines      JSONB       DEFAULT '[]',
  total_ht   DECIMAL(10,2) DEFAULT 0,
  total_tva  DECIMAL(10,2) DEFAULT 0,
  total_ttc  DECIMAL(10,2) DEFAULT 0,
  due_date   DATE,
  paid_at    TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── BONS D'INTERVENTION ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS intervention_reports (
  id                   UUID        DEFAULT gen_random_uuid() PRIMARY KEY,
  mission_id           TEXT        REFERENCES missions(id)  ON DELETE CASCADE,
  work_done            TEXT,
  materials_used       TEXT,
  start_time           TIMESTAMPTZ,
  end_time             TIMESTAMPTZ,
  client_name          TEXT,
  client_signature     TEXT,
  technician_signature TEXT,
  signed_at            TIMESTAMPTZ,
  pdf_url              TEXT,
  created_at           TIMESTAMPTZ DEFAULT NOW()
);

-- ── NOTIFICATIONS ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
  id         UUID        DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id    UUID        REFERENCES users(id)     ON DELETE CASCADE,
  type       TEXT        NOT NULL,
  title      TEXT        NOT NULL,
  message    TEXT,
  mission_id TEXT        REFERENCES missions(id)  ON DELETE SET NULL,
  read       BOOLEAN     DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── MESSAGES ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS messages (
  id             UUID        DEFAULT gen_random_uuid() PRIMARY KEY,
  mission_id     TEXT        REFERENCES missions(id)  ON DELETE CASCADE,
  sender_id      UUID        REFERENCES users(id)     ON DELETE SET NULL,
  content        TEXT        NOT NULL,
  attachment_url TEXT,
  read           BOOLEAN     DEFAULT false,
  created_at     TIMESTAMPTZ DEFAULT NOW()
);

-- ── INDEX DE PERFORMANCE ─────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_missions_status     ON missions(status);
CREATE INDEX IF NOT EXISTS idx_missions_priority   ON missions(priority);
CREATE INDEX IF NOT EXISTS idx_missions_agency     ON missions(agency_id);
CREATE INDEX IF NOT EXISTS idx_quotes_mission      ON quotes(mission_id);
CREATE INDEX IF NOT EXISTS idx_invoices_mission    ON invoices(mission_id);
CREATE INDEX IF NOT EXISTS idx_messages_mission    ON messages(mission_id);
CREATE INDEX IF NOT EXISTS idx_notifs_user         ON notifications(user_id, read);
CREATE INDEX IF NOT EXISTS idx_users_clerk         ON users(clerk_id);

-- ── TRIGGER : updated_at auto ────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS missions_updated_at ON missions;
CREATE TRIGGER missions_updated_at
  BEFORE UPDATE ON missions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ── ROW LEVEL SECURITY ───────────────────────────────────────
ALTER TABLE missions              ENABLE ROW LEVEL SECURITY;
ALTER TABLE users                 ENABLE ROW LEVEL SECURITY;
ALTER TABLE quotes                ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices              ENABLE ROW LEVEL SECURITY;
ALTER TABLE intervention_reports  ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications         ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages              ENABLE ROW LEVEL SECURITY;

-- Politique : service_role a accès total (pour les API routes Next.js)
CREATE POLICY "Service role full access - missions"             ON missions             FOR ALL TO service_role USING (true);
CREATE POLICY "Service role full access - users"               ON users                FOR ALL TO service_role USING (true);
CREATE POLICY "Service role full access - quotes"              ON quotes               FOR ALL TO service_role USING (true);
CREATE POLICY "Service role full access - invoices"            ON invoices             FOR ALL TO service_role USING (true);
CREATE POLICY "Service role full access - reports"             ON intervention_reports FOR ALL TO service_role USING (true);
CREATE POLICY "Service role full access - notifications"       ON notifications        FOR ALL TO service_role USING (true);
CREATE POLICY "Service role full access - messages"            ON messages             FOR ALL TO service_role USING (true);

-- ── DONNÉES DE DÉMONSTRATION ─────────────────────────────────
INSERT INTO agencies (id, name, email, phone, address) VALUES
  ('a1000000-0000-0000-0000-000000000001', 'Agence Voltaire Immobilier', 'contact@voltaire-immo.fr', '01 23 45 67 89', '15 rue Voltaire, Paris 11e'),
  ('a1000000-0000-0000-0000-000000000002', 'Gestion Locative Haussmann', 'info@haussmann-gestion.fr', '01 34 56 78 90', '45 bd Haussmann, Paris 8e'),
  ('a1000000-0000-0000-0000-000000000003', 'Paris Est Gestion',          'paris@est-gestion.fr',    '01 45 67 89 01', '8 rue de la Roquette, Paris 11e')
ON CONFLICT DO NOTHING;

INSERT INTO categories (name, icon, color, is_urgent) VALUES
  ('Plomberie',     '🔧', '#0EA5E9', false),
  ('Électricité',   '⚡', '#F59E0B', false),
  ('Serrurerie',    '🔑', '#8B5CF6', false),
  ('Menuiserie',    '🪚', '#A16207', false),
  ('Vitrerie',      '🪟', '#06B6D4', false),
  ('Chauffage',     '🔥', '#EF4444', false),
  ('Climatisation', '❄️', '#3B82F6', false),
  ('Peinture',      '🎨', '#10B981', false),
  ('Urgence',       '🚨', '#EF4444', true)
ON CONFLICT DO NOTHING;

SELECT 'Base de données INTERVIA créée avec succès ! ✅' AS resultat,
       (SELECT COUNT(*) FROM agencies)   AS agences,
       (SELECT COUNT(*) FROM categories) AS categories;
