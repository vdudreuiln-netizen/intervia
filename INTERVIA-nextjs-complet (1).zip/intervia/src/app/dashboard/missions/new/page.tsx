'use client'

import { useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { CATEGORIES } from '@/lib/constants'
import toast from 'react-hot-toast'

const STEPS = ['Métier', 'Détails', 'Photos', 'Confirmation']

export default function NewMissionPage() {
  const router = useRouter()
  const [step, setStep] = useState(0)
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    catId: '', sub: '', description: '', address: '', contactName: '', contactPhone: '', urgent: false, photos: [] as { name: string; url: string; size: string }[],
  })
  const fileRef = useRef<HTMLInputElement>(null)
  const upd = (patch: Partial<typeof form>) => setForm(p => ({ ...p, ...patch }))
  const cat = CATEGORIES.find(c => c.id === form.catId)

  const handleFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? [])
    const previews = files.map(f => ({ name: f.name, url: URL.createObjectURL(f), size: (f.size / 1024).toFixed(0) + ' KB' }))
    upd({ photos: [...form.photos, ...previews] })
  }

  const submit = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/missions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, categoryLabel: cat?.label }),
      })
      if (!res.ok) throw new Error()
      toast.success('Mission créée avec succès !')
      router.push('/dashboard/missions')
    } catch {
      toast.error('Erreur lors de la création. Réessayez.')
      setLoading(false)
    }
  }

  const inputCls = 'w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-sm outline-none focus:border-blue-400 transition-colors font-[inherit]'

  return (
    <div className="max-w-2xl mx-auto animate-fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-black tracking-tight" style={{ color: '#0D1B35' }}>Nouvelle intervention</h1>
        <p className="text-slate-500 text-sm mt-1">Remplissez le formulaire pour soumettre une demande.</p>
      </div>

      {/* Stepper */}
      <div className="flex gap-2 mb-8">
        {STEPS.map((s, i) => (
          <div key={s} className="flex-1">
            <div className="h-1.5 rounded-full mb-1.5 transition-all" style={{ background: step > i ? '#10B981' : step === i ? '#2563EB' : '#E2E8F0' }} />
            <span className="text-xs font-bold" style={{ color: step >= i ? '#2563EB' : '#94A3B8' }}>{s}</span>
          </div>
        ))}
      </div>

      <div className="card p-8">

        {/* ── STEP 0 : Métier ── */}
        {step === 0 && (
          <div>
            <h2 className="text-lg font-bold mb-1" style={{ color: '#0D1B35' }}>Quel type d'intervention ?</h2>
            <p className="text-slate-500 text-sm mb-6">Sélectionnez le métier correspondant.</p>
            <div className="grid grid-cols-3 gap-3">
              {CATEGORIES.map(c => (
                <button key={c.id} onClick={() => { upd({ catId: c.id }); setStep(1) }}
                  className="flex flex-col items-center gap-2 p-4 rounded-2xl border-2 transition-all hover:scale-[1.02]"
                  style={{ borderColor: form.catId === c.id ? c.color : '#E2E8F0', background: form.catId === c.id ? c.color + '12' : '#fff' }}>
                  <span className="text-3xl">{c.icon}</span>
                  <span className="text-xs font-bold" style={{ color: c.id === 'urgence' ? '#EF4444' : '#0D1B35' }}>{c.label}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* ── STEP 1 : Détails ── */}
        {step === 1 && cat && (
          <div className="flex flex-col gap-5">
            <h2 className="text-lg font-bold" style={{ color: '#0D1B35' }}>{cat.icon} {cat.label} — Précisez</h2>

            <div>
              <label className="block text-sm font-bold mb-2" style={{ color: '#0D1B35' }}>Sous-catégorie *</label>
              <div className="flex flex-wrap gap-2">
                {cat.subs.map(s => (
                  <button key={s} onClick={() => upd({ sub: s })}
                    className="px-4 py-1.5 rounded-full text-sm font-bold border transition-all"
                    style={{ borderColor: form.sub === s ? '#2563EB' : '#E2E8F0', background: form.sub === s ? '#EFF6FF' : '#fff', color: form.sub === s ? '#1D4ED8' : '#64748B' }}>
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold mb-2" style={{ color: '#0D1B35' }}>Adresse du bien *</label>
              <input value={form.address} onChange={e => upd({ address: e.target.value })} placeholder="Ex : 12 rue Voltaire, Paris 75011" className={inputCls} />
            </div>

            <div>
              <label className="block text-sm font-bold mb-2" style={{ color: '#0D1B35' }}>Description détaillée *</label>
              <textarea value={form.description} onChange={e => upd({ description: e.target.value })} placeholder="Décrivez précisément le problème…" rows={4} className={inputCls + ' resize-y'} />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-bold mb-2" style={{ color: '#0D1B35' }}>Nom du locataire</label>
                <input value={form.contactName} onChange={e => upd({ contactName: e.target.value })} placeholder="Jean Dupont" className={inputCls} />
              </div>
              <div>
                <label className="block text-sm font-bold mb-2" style={{ color: '#0D1B35' }}>Téléphone</label>
                <input value={form.contactPhone} onChange={e => upd({ contactPhone: e.target.value })} placeholder="06 12 34 56 78" className={inputCls} />
              </div>
            </div>

            <label className="flex items-center gap-3 p-4 rounded-xl cursor-pointer" style={{ background: '#FFF7ED', border: '1.5px solid #FED7AA' }}>
              <input type="checkbox" checked={form.urgent} onChange={e => upd({ urgent: e.target.checked })} className="w-5 h-5 cursor-pointer" />
              <div>
                <div className="font-bold text-sm" style={{ color: '#92400E' }}>🚨 Marquer comme URGENT</div>
                <div className="text-xs" style={{ color: '#B45309' }}>Intervention demandée dans les 4 heures</div>
              </div>
            </label>

            <div className="flex gap-3 pt-2">
              <button onClick={() => setStep(0)} className="px-5 py-2.5 rounded-xl font-bold text-sm border border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 transition-colors">← Retour</button>
              <button onClick={() => setStep(2)} disabled={!form.sub || !form.address || !form.description}
                className="flex-1 py-2.5 rounded-xl font-bold text-sm text-white transition-all hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed"
                style={{ background: '#2563EB' }}>
                Suivant →
              </button>
            </div>
          </div>
        )}

        {/* ── STEP 2 : Photos ── */}
        {step === 2 && (
          <div className="flex flex-col gap-5">
            <h2 className="text-lg font-bold" style={{ color: '#0D1B35' }}>Ajoutez des photos</h2>
            <p className="text-slate-500 text-sm -mt-3">Des visuels aident le technicien à préparer l'intervention.</p>

            <div onClick={() => fileRef.current?.click()}
              className="border-2 border-dashed border-slate-200 rounded-2xl p-10 text-center cursor-pointer hover:border-blue-300 hover:bg-blue-50/30 transition-all">
              <div className="text-5xl mb-3">📸</div>
              <div className="font-bold text-sm" style={{ color: '#0D1B35' }}>Cliquez pour ajouter des photos</div>
              <div className="text-slate-400 text-xs mt-1">ou glissez-déposez ici · JPEG, PNG, HEIC</div>
              <input ref={fileRef} type="file" accept="image/*" multiple onChange={handleFiles} className="hidden" />
            </div>

            {form.photos.length > 0 && (
              <div className="grid grid-cols-4 gap-3">
                {form.photos.map((p, i) => (
                  <div key={i} className="relative aspect-square rounded-xl overflow-hidden border border-slate-200">
                    <img src={p.url} alt={p.name} className="w-full h-full object-cover" />
                    <div className="absolute inset-x-0 bottom-0 bg-black/50 px-2 py-1">
                      <span className="text-white text-[10px]">{p.size}</span>
                    </div>
                    <button onClick={() => upd({ photos: form.photos.filter((_, j) => j !== i) })}
                      className="absolute top-1 right-1 w-5 h-5 bg-black/50 rounded-full text-white flex items-center justify-center text-xs hover:bg-red-500 transition-colors">×</button>
                  </div>
                ))}
              </div>
            )}

            <div className="flex gap-3 pt-2">
              <button onClick={() => setStep(1)} className="px-5 py-2.5 rounded-xl font-bold text-sm border border-slate-200 bg-slate-50 text-slate-700">← Retour</button>
              <button onClick={() => setStep(3)} className="flex-1 py-2.5 rounded-xl font-bold text-sm text-white" style={{ background: '#2563EB' }}>Suivant →</button>
            </div>
          </div>
        )}

        {/* ── STEP 3 : Confirmation ── */}
        {step === 3 && (
          <div className="flex flex-col gap-5">
            <div className="text-center">
              <div className="text-5xl mb-3">✅</div>
              <h2 className="text-lg font-bold" style={{ color: '#0D1B35' }}>Confirmez votre demande</h2>
            </div>

            {form.urgent && (
              <div className="flex items-center gap-3 p-4 rounded-xl" style={{ background: '#FFF1F2', border: '1.5px solid #FECDD3' }}>
                <span className="text-2xl">🚨</span>
                <div>
                  <div className="font-bold text-sm" style={{ color: '#EF4444' }}>Intervention URGENTE</div>
                  <div className="text-xs" style={{ color: '#9F1239' }}>Un technicien sera dépêché dans les 4 heures</div>
                </div>
              </div>
            )}

            <div className="rounded-xl p-5 flex flex-col gap-3" style={{ background: '#F8FAFC' }}>
              {[
                ['Catégorie',  `${cat?.icon} ${cat?.label}`],
                ['Problème',   form.sub],
                ['Adresse',    form.address],
                ['Contact',    [form.contactName, form.contactPhone].filter(Boolean).join(' · ') || '—'],
                ['Photos',     `${form.photos.length} photo(s)`],
                ['Urgence',    form.urgent ? '🚨 Oui' : 'Non'],
              ].map(([k, v]) => (
                <div key={k} className="flex gap-3">
                  <span className="text-slate-400 text-sm font-bold min-w-[90px]">{k}</span>
                  <span className="text-sm font-medium" style={{ color: '#0D1B35' }}>{v}</span>
                </div>
              ))}
            </div>

            <div className="flex gap-3 pt-2">
              <button onClick={() => setStep(2)} className="px-5 py-2.5 rounded-xl font-bold text-sm border border-slate-200 bg-slate-50 text-slate-700">← Retour</button>
              <button onClick={submit} disabled={loading}
                className="flex-1 py-2.5 rounded-xl font-bold text-sm text-white transition-all hover:opacity-90 disabled:opacity-60 flex items-center justify-center gap-2"
                style={{ background: '#2563EB' }}>
                {loading ? 'Envoi en cours…' : '🚀 Envoyer la demande'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
