'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useUser } from '@clerk/nextjs'
import { CATEGORIES } from '@/lib/constants'
import { formatCurrency } from '@/lib/utils'

const DEMO_MISSIONS = [
  { id:'M-2024-001', agency:'Agence Voltaire Immobilier',  address:'12 rue Voltaire, Paris 11e',      cat:'Plomberie',   sub:'Fuite robinet',          status:'En cours',     priority:'urgent', date:'15/01/2024', tech:'Jean Moreau',  quoteHT:233 },
  { id:'M-2024-002', agency:'Gestion Locative Haussmann',  address:'45 bd Haussmann, Paris 8e',       cat:'Électricité', sub:'Panne tableau électrique',status:'Devis envoyé', priority:'normal', date:'14/01/2024', tech:'Pierre Duval', quoteHT:375 },
  { id:'M-2024-003', agency:'Paris Est Gestion',           address:'8 rue de la Roquette, Paris 11e', cat:'Serrurerie',  sub:'Porte claquée',          status:'Terminé',      priority:'urgent', date:'13/01/2024', tech:'Jean Moreau',  quoteHT:158 },
  { id:'M-2024-004', agency:'Agence Voltaire Immobilier',  address:'3 rue Oberkampf, Paris 11e',      cat:'Peinture',    sub:'Dégât des eaux',         status:'Planifié',     priority:'normal', date:'16/01/2024', tech:'Sophie Blanc', quoteHT:567 },
  { id:'M-2024-005', agency:'Sud Paris Immobilier',        address:'22 av. d\'Italie, Paris 13e',     cat:'Chauffage',   sub:'Chaudière en panne',     status:'En cours',     priority:'urgent', date:'15/01/2024', tech:'Pierre Duval', quoteHT:267 },
  { id:'M-2024-006', agency:'Nord Immo Gestion',           address:'5 rue Marx Dormoy, Paris 18e',    cat:'Vitrerie',    sub:'Vitre cassée',           status:'Nouveau',      priority:'normal', date:'16/01/2024', tech:'Non assigné',  quoteHT:0   },
]

const STATUS_COLORS: Record<string, string> = {
  'Nouveau':      'bg-slate-100 text-slate-600',
  'En cours':     'bg-blue-50 text-blue-700',
  'Devis envoyé': 'bg-amber-50 text-amber-800',
  'Planifié':     'bg-violet-50 text-violet-700',
  'Terminé':      'bg-emerald-50 text-emerald-700',
  'Annulé':       'bg-red-50 text-red-700',
}

const FILTERS = [
  { key:'all',          label:'Toutes' },
  { key:'Nouveau',      label:'Nouvelles' },
  { key:'En cours',     label:'En cours' },
  { key:'Devis envoyé', label:'Devis' },
  { key:'Planifié',     label:'Planifiées' },
  { key:'Terminé',      label:'Terminées' },
  { key:'urgent',       label:'🚨 Urgences' },
]

export default function MissionsPage() {
  const { user } = useUser()
  const role = (user?.publicMetadata?.role as string) ?? 'agency'
  const [filter, setFilter] = useState('all')
  const [search, setSearch] = useState('')
  const [missions] = useState(DEMO_MISSIONS)

  const filtered = missions.filter(m => {
    const mf = filter === 'all' || m.status === filter || (filter === 'urgent' && m.priority === 'urgent')
    const ms = !search || [m.id, m.agency, m.cat, m.sub, m.address].join(' ').toLowerCase().includes(search.toLowerCase())
    return mf && ms
  })

  const count = (f: string) => f === 'all' ? missions.length : f === 'urgent' ? missions.filter(m => m.priority === 'urgent').length : missions.filter(m => m.status === f).length

  return (
    <div className="flex flex-col gap-5 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black tracking-tight" style={{ color: '#0D1B35' }}>Missions</h1>
          <p className="text-slate-500 text-sm mt-0.5">{filtered.length} mission(s) trouvée(s)</p>
        </div>
        {role === 'agency' && (
          <Link href="/dashboard/missions/new"
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-sm text-white transition-all hover:opacity-90"
            style={{ background: '#2563EB' }}>
            + Nouvelle intervention
          </Link>
        )}
      </div>

      {/* Filters */}
      <div className="flex gap-2 flex-wrap">
        {FILTERS.map(f => (
          <button key={f.key} onClick={() => setFilter(f.key)}
            className={`px-4 py-1.5 rounded-full text-sm font-bold border transition-all ${filter === f.key ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-slate-200 bg-white text-slate-500 hover:border-slate-300'}`}>
            {f.label} <span className="opacity-50">({count(f.key)})</span>
          </button>
        ))}
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="🔍 Rechercher…"
          className="ml-auto px-4 py-1.5 rounded-full text-sm border border-slate-200 bg-white outline-none w-56 focus:border-blue-400 transition-colors"
          style={{ fontFamily: 'inherit' }} />
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b-2 border-slate-100">
              {['Référence', 'Agence', 'Catégorie', 'Adresse', 'Technicien', 'Statut', 'Devis HT', 'Date', ''].map(h => (
                <th key={h} className="text-left px-5 py-3 text-xs font-bold text-slate-400 uppercase tracking-wide whitespace-nowrap">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map(m => (
              <tr key={m.id} className="hover-row border-b border-slate-50 cursor-pointer">
                <td className="px-5 py-3.5">
                  <div className="flex items-center gap-2">
                    <span className="font-black text-sm" style={{ color: '#0D1B35' }}>{m.id}</span>
                    {m.priority === 'urgent' && (
                      <span className="bg-red-50 text-red-600 text-[10px] font-bold px-1.5 py-0.5 rounded-full">🚨</span>
                    )}
                  </div>
                </td>
                <td className="px-5 py-3.5 text-sm font-semibold" style={{ color: '#0D1B35' }}>{m.agency}</td>
                <td className="px-5 py-3.5">
                  <span className="flex items-center gap-1.5 text-sm" style={{ color: '#0D1B35' }}>
                    {CATEGORIES.find(c => c.label === m.cat)?.icon} {m.cat}
                  </span>
                </td>
                <td className="px-5 py-3.5 text-sm text-slate-500 max-w-[180px]">
                  <div className="truncate">{m.address}</div>
                </td>
                <td className="px-5 py-3.5 text-sm" style={{ color: '#0D1B35' }}>{m.tech}</td>
                <td className="px-5 py-3.5">
                  <span className={`badge ${STATUS_COLORS[m.status] ?? ''}`}>
                    <span className="w-1.5 h-1.5 rounded-full bg-current opacity-60" />
                    {m.status}
                  </span>
                </td>
                <td className="px-5 py-3.5 font-bold text-sm" style={{ color: '#0D1B35' }}>
                  {m.quoteHT ? formatCurrency(m.quoteHT) : '—'}
                </td>
                <td className="px-5 py-3.5 text-sm text-slate-400 whitespace-nowrap">{m.date}</td>
                <td className="px-5 py-3.5">
                  <Link href={`/dashboard/missions/${m.id}`}
                    className="text-xs font-bold px-3 py-1.5 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 transition-colors">
                    Ouvrir
                  </Link>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr><td colSpan={9} className="text-center py-16">
                <div className="text-4xl mb-3">🔍</div>
                <div className="text-slate-500 font-medium">Aucune mission trouvée</div>
              </td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
