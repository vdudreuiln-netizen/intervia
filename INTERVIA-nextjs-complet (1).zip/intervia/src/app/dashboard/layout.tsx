'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { UserButton, useUser } from '@clerk/nextjs'
import { cn } from '@/lib/utils'

const NAV = [
  { href: '/dashboard',          icon: '🏠', label: 'Tableau de bord' },
  { href: '/dashboard/missions', icon: '📋', label: 'Missions',        badge: true },
  { href: '/dashboard/calendar', icon: '📅', label: 'Planning' },
  { href: '/dashboard/quotes',   icon: '💰', label: 'Devis' },
  { href: '/dashboard/invoices', icon: '🧾', label: 'Factures' },
  { href: '/dashboard/messages', icon: '💬', label: 'Messages' },
]

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { user } = useUser()
  const pathname = usePathname()
  const [mobileOpen, setMobileOpen] = useState(false)
  const role = (user?.publicMetadata?.role as string) ?? 'agency'

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: '#F1F5F9' }}>

      {/* ── SIDEBAR ── */}
      <aside className={cn(
        'flex flex-col flex-shrink-0 transition-transform duration-300',
        'w-[248px]',
        mobileOpen ? 'translate-x-0' : '',
      )} style={{ background: '#0D1B35', height: '100vh', position: 'sticky', top: 0 }}>

        {/* Logo */}
        <div className="flex items-center gap-3 px-5 py-6 border-b border-white/8">
          <svg width="34" height="34" viewBox="0 0 48 48" fill="none">
            <rect width="48" height="48" rx="12" fill="rgba(255,255,255,.1)"/>
            <path d="M24 9L39 17.5V26C39 34.5 31.5 40.5 24 43C16.5 40.5 9 34.5 9 26V17.5L24 9Z" fill="#2563EB" opacity=".9"/>
            <path d="M19 24h10M24 19v10" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
          </svg>
          <span style={{ fontFamily:"'DM Sans',sans-serif", fontWeight:900, fontSize:20, letterSpacing:'-.5px', color:'#fff' }}>
            INTER<span style={{ color:'rgba(255,255,255,.4)' }}>VIA</span>
          </span>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 flex flex-col gap-1 overflow-y-auto">
          {NAV.map(({ href, icon, label, badge }) => {
            const active = pathname === href || (href !== '/dashboard' && pathname.startsWith(href))
            return (
              <Link key={href} href={href}
                className={cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all',
                  active
                    ? 'bg-white/12 text-white font-bold'
                    : 'text-white/40 hover:text-white/70 hover:bg-white/6',
                )}>
                <span className="text-lg">{icon}</span>
                <span>{label}</span>
                {badge && label === 'Missions' && (
                  <span className="ml-auto bg-red-500 text-white text-[11px] font-bold px-2 py-0.5 rounded-full">3</span>
                )}
              </Link>
            )
          })}
        </nav>

        {/* Nouvelle intervention (agence) */}
        {role === 'agency' && (
          <div className="px-3 pb-3">
            <Link href="/dashboard/missions/new"
              className="flex items-center justify-center gap-2 w-full py-3 rounded-xl font-bold text-sm text-white transition-all hover:opacity-90"
              style={{ background: '#2563EB' }}>
              + Nouvelle intervention
            </Link>
          </div>
        )}

        {/* User */}
        <div className="flex items-center gap-3 px-4 py-4 border-t border-white/8">
          <UserButton afterSignOutUrl="/sign-in" appearance={{ elements: { avatarBox: 'w-9 h-9' } }} />
          <div className="min-w-0">
            <div className="text-white text-sm font-bold truncate">{user?.fullName ?? 'Utilisateur'}</div>
            <div className="text-white/35 text-xs truncate">{user?.primaryEmailAddress?.emailAddress}</div>
          </div>
        </div>
      </aside>

      {/* ── MAIN ── */}
      <div className="flex-1 flex flex-col overflow-hidden">

        {/* Topbar */}
        <header className="flex items-center justify-between px-7 h-[58px] bg-white border-b border-slate-200 flex-shrink-0 sticky top-0 z-20">
          <div className="flex items-center gap-3">
            <input placeholder="🔍  Rechercher une mission…"
              className="pl-4 pr-4 py-2 rounded-xl border border-slate-200 text-sm bg-slate-50 outline-none w-64 focus:border-blue-400 transition-colors"
              style={{ fontFamily: 'inherit' }} />
          </div>
          <div className="flex items-center gap-3">
            <Link href="/dashboard/notifications"
              className="relative flex items-center justify-center w-10 h-10 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 transition-colors text-lg">
              🔔
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-[10px] text-white font-bold flex items-center justify-center">3</span>
            </Link>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">
          <div className="max-w-[1400px] mx-auto p-7">
            {children}
          </div>
        </main>
      </div>
    </div>
  )
}
