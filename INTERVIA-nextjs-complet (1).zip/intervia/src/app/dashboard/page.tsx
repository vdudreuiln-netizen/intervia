import { auth } from '@clerk/nextjs/server'
import { supabaseAdmin } from '@/lib/supabase'
import { formatCurrency } from '@/lib/utils'
import Link from 'next/link'

async function getStats() {
  try {
    const db = supabaseAdmin()
    const [{ count: total }, { count: enCours }, { count: urgent }, { data: quoteData }] = await Promise.all([
      db.from('missions').select('*', { count: 'exact', head: true }),
      db.from('missions').select('*', { count: 'exact', head: true }).eq('status', 'En cours'),
      db.from('missions').select('*', { count: 'exact', head: true }).eq('priority', 'urgent'),
      db.from('quotes').select('total_ttc'),
    ])
    const ca = quoteData?.reduce((acc, q) => acc + (q.total_ttc ?? 0), 0) ?? 0
    return { total: total ?? 0, enCours: enCours ?? 0, urgent: urgent ?? 0, ca }
  } catch {
    return { total: 6, enCours: 2, urgent: 3, ca: 1920 }
  }
}

async function getRecentMissions() {
  try {
    const db = supabaseAdmin()
    const { data } = await db.from('missions').select('*, agencies(name)').order('created_at', { ascending: false }).limit(6)
    return data ?? []
  } catch {
    return DEMO_MISSIONS
  }
}

const DEMO_MISSIONS = [
  { id: 'M-2024-001', agencies: { name: 'Agence Voltaire' }, subcategory: 'Fuite robinet',           status: 'En cours',     priority: 'urgent', created_at: '2024-01-15', total_ht: 233 },
  { id: 'M-2024-002', agencies: { name: 'Gestion Haussmann'}, subcategory: 'Panne tableau',           status: 'Devis envoyé', priority: 'normal', created_at: '2024-01-14', total_ht: 375 },
  { id: 'M-2024-003', agencies: { name: 'Paris Est Gestion'}, subcategory: 'Porte claquée',           status: 'Terminé',      priority: 'urgent', created_at: '2024-01-13', total_ht: 158 },
  { id: 'M-2024-004', agencies: { name: 'Agence Voltaire' }, subcategory: 'Dégât des eaux',           status: 'Planifié',     priority: 'normal', created_at: '2024-01-16', total_ht: 567 },
  { id: 'M-2024-005', agencies: { name: 'Sud Paris Immo'  }, subcategory: 'Chaudière en panne',       status: 'En cours',     priority: 'urgent', created_at: '2024-01-15', total_ht: 267 },
  { id: 'M-2024-006', agencies: { name: 'Nord Immo'       }, subcategory: 'Vitre cassée',             status: 'Nouveau',      priority: 'normal', created_at: '2024-01-16', total_ht: 0   },
]

const STATUS_COLORS: Record<string, string> = {
  'Nouveau':      'bg-slate-100 text-slate-600',
  'En cours':     'bg-blue-50 text-blue-700',
  'Devis envoyé': 'bg-amber-50 text-amber-800',
  'Planifié':     'bg-violet-50 text-violet-700',
  'Terminé':      'bg-emerald-50 text-emerald-700',
}

export default async function DashboardPage() {
  const [stats, missions] = await Promise.all([getStats(), getRecentMissions()])

  const statCards = [
    { icon: '📋', label: 'Missions totales', value: stats.total,            color: '#2563EB', trend: '↑ +3 ce mois' },
    { icon: '⚡', label: 'En cours',         value: stats.enCours,          color: '#F59E0B', trend: null },
    { icon: '🚨', label: 'Urgences actives', value: stats.urgent,           color: '#EF4444', trend: null },
    { icon: '💰', label: 'CA potentiel HT',  value: formatCurrency(stats.ca),color: '#10B981', trend: '↑ +12%' },
  ]

  return (
    <div className="flex flex-col gap-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-black tracking-tight" style={{ color: '#0D1B35' }}>Tableau de bord 👋</h1>
        <p className="text-slate-500 text-sm mt-1">Voici un résumé de votre activité.</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-4 gap-4">
        {statCards.map((s) => (
          <div key={s.label} className="card p-5">
            <div className="flex justify-between items-start">
              <div>
                <div className="text-slate-500 text-sm font-medium mb-1.5">{s.label}</div>
                <div className="text-3xl font-black tracking-tight" style={{ color: '#0D1B35' }}>{s.value}</div>
                {s.trend && <div className="text-emerald-600 text-xs font-bold mt-1">{s.trend}</div>}
              </div>
              <div className="w-11 h-11 rounded-xl flex items-center justify-center text-2xl" style={{ background: s.color + '18' }}>{s.icon}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent missions */}
      <div className="card overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <h2 className="font-bold text-base" style={{ color: '#0D1B35' }}>Missions récentes</h2>
          <Link href="/dashboard/missions" className="text-sm font-bold text-blue-600 hover:text-blue-700">Voir tout →</Link>
        </div>
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b-2 border-slate-100">
              {['Référence', 'Agence', 'Problème', 'Statut', 'Date', ''].map(h => (
                <th key={h} className="text-left px-6 py-3 text-xs font-bold text-slate-400 uppercase tracking-wide">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {(missions as any[]).map((m) => (
              <tr key={m.id} className="hover-row border-b border-slate-50 cursor-pointer">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm" style={{ color: '#0D1B35' }}>{m.id}</span>
                    {m.priority === 'urgent' && <span className="bg-red-50 text-red-600 text-[10px] font-bold px-2 py-0.5 rounded-full">🚨 URGENT</span>}
                  </div>
                </td>
                <td className="px-6 py-4 text-sm font-medium" style={{ color: '#0D1B35' }}>{m.agencies?.name ?? '—'}</td>
                <td className="px-6 py-4 text-sm text-slate-500">{m.subcategory}</td>
                <td className="px-6 py-4">
                  <span className={`badge ${STATUS_COLORS[m.status] ?? 'bg-slate-100 text-slate-500'}`}>
                    <span className="w-1.5 h-1.5 rounded-full bg-current opacity-70" />
                    {m.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-slate-400">{new Date(m.created_at).toLocaleDateString('fr-FR')}</td>
                <td className="px-6 py-4">
                  <Link href={`/dashboard/missions/${m.id}`} className="text-xs font-bold text-blue-600 hover:underline">Ouvrir</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { icon: '📋', label: 'Créer un devis', desc: 'Générer un devis pour une mission', href: '/dashboard/quotes/new', color: '#2563EB' },
          { icon: '📅', label: 'Voir le planning', desc: 'Gérer les interventions planifiées', href: '/dashboard/calendar', color: '#8B5CF6' },
          { icon: '🧾', label: 'Émettre une facture', desc: 'Créer et envoyer une facture', href: '/dashboard/invoices/new', color: '#10B981' },
        ].map(a => (
          <Link key={a.label} href={a.href} className="card p-5 flex gap-4 items-center hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0" style={{ background: a.color + '15' }}>{a.icon}</div>
            <div>
              <div className="font-bold text-sm" style={{ color: '#0D1B35' }}>{a.label}</div>
              <div className="text-slate-500 text-xs mt-0.5">{a.desc}</div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
