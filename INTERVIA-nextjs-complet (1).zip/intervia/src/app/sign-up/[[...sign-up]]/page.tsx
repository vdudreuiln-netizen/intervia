import { SignUp } from '@clerk/nextjs'

export default function SignUpPage() {
  return (
    <div className="min-h-screen flex items-center justify-center p-4"
      style={{ background: 'linear-gradient(135deg, #0D1B35 0%, #162C5A 60%, #1E3A8A 100%)' }}>
      <div className="fixed inset-0 pointer-events-none"
        style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,.03) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.03) 1px,transparent 1px)', backgroundSize: '48px 48px' }} />
      <div className="relative w-full max-w-md">
        <div className="text-center mb-8">
          <span style={{ fontFamily: "'DM Sans',sans-serif", fontWeight: 900, fontSize: 28, letterSpacing: '-.6px', color: '#fff' }}>
            INTER<span style={{ color: 'rgba(255,255,255,.45)' }}>VIA</span>
          </span>
          <p style={{ color: 'rgba(255,255,255,.4)', fontSize: 14, marginTop: 6 }}>Créez votre compte</p>
        </div>
        <SignUp appearance={{
          elements: {
            rootBox:           'w-full',
            card:              'rounded-2xl shadow-2xl border border-white/10 bg-white/5 backdrop-blur-xl',
            headerTitle:       'text-white font-bold text-xl',
            headerSubtitle:    'text-white/50',
            formFieldInput:    'bg-white/10 border-white/20 text-white placeholder:text-white/30 rounded-xl',
            formFieldLabel:    'text-white/70 font-semibold text-sm',
            formButtonPrimary: 'bg-blue-600 hover:bg-blue-700 rounded-xl font-bold',
            footerActionLink:  'text-blue-400 hover:text-blue-300',
          },
        }} />
      </div>
    </div>
  )
}
