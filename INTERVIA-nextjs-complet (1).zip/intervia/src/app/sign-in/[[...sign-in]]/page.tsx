import { SignIn } from '@clerk/nextjs'

export default function SignInPage() {
  return (
    <div className="min-h-screen flex items-center justify-center p-4"
      style={{ background: 'linear-gradient(135deg, #0D1B35 0%, #162C5A 60%, #1E3A8A 100%)' }}>

      {/* Grid bg */}
      <div className="fixed inset-0 pointer-events-none"
        style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,.03) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.03) 1px,transparent 1px)', backgroundSize: '48px 48px' }} />

      <div className="relative w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 mb-3">
            <svg width="44" height="44" viewBox="0 0 48 48" fill="none">
              <rect width="48" height="48" rx="13" fill="rgba(255,255,255,.12)"/>
              <path d="M24 9L39 17.5V26C39 34.5 31.5 40.5 24 43C16.5 40.5 9 34.5 9 26V17.5L24 9Z" fill="#2563EB" opacity=".9"/>
              <path d="M19 24h10M24 19v10" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
              <circle cx="24" cy="24" r="3.5" fill="white" opacity=".35"/>
            </svg>
            <span style={{ fontFamily: "'DM Sans',sans-serif", fontWeight: 900, fontSize: 28, letterSpacing: '-.6px', color: '#fff' }}>
              INTER<span style={{ color: 'rgba(255,255,255,.45)' }}>VIA</span>
            </span>
          </div>
          <p style={{ color: 'rgba(255,255,255,.4)', fontSize: 14 }}>Plateforme de gestion d'interventions</p>
        </div>

        <SignIn
          appearance={{
            elements: {
              rootBox:           'w-full',
              card:              'rounded-2xl shadow-2xl border border-white/10 bg-white/5 backdrop-blur-xl',
              headerTitle:       'text-white font-bold text-xl',
              headerSubtitle:    'text-white/50',
              formFieldInput:    'bg-white/10 border-white/20 text-white placeholder:text-white/30 rounded-xl focus:border-blue-400',
              formFieldLabel:    'text-white/70 font-semibold text-sm',
              formButtonPrimary: 'bg-blue-600 hover:bg-blue-700 rounded-xl font-bold text-sm',
              footerActionLink:  'text-blue-400 hover:text-blue-300',
              dividerLine:       'bg-white/10',
              dividerText:       'text-white/30',
              socialButtonsIconButton: 'border-white/20 bg-white/5 hover:bg-white/10',
              identityPreviewText: 'text-white',
              identityPreviewEditButton: 'text-blue-400',
            },
          }}
        />
      </div>
    </div>
  )
}
