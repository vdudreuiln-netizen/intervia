import { auth } from '@clerk/nextjs/server'
import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { generateInvoicePDF } from '@/lib/pdf'
import { sendInvoiceEmail } from '@/lib/emails'
import { generateInvoiceNumber, calcQuoteTotals } from '@/lib/utils'

export async function GET(req: NextRequest) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 })

  try {
    const db = supabaseAdmin()
    const { data, error } = await db.from('invoices')
      .select('*, missions(id, address, agencies(name))')
      .order('created_at', { ascending: false })
    if (error) throw error
    return NextResponse.json(data)
  } catch {
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 })

  try {
    const { missionId, quoteId, lines, dueDate } = await req.json()
    const { totalHT, totalTVA, totalTTC } = calcQuoteTotals(lines)
    const db     = supabaseAdmin()
    const number = generateInvoiceNumber()

    const { data, error } = await db.from('invoices').insert({
      mission_id: missionId,
      quote_id:   quoteId,
      number,
      status:     'draft',
      lines,
      total_ht:   totalHT,
      total_tva:  totalTVA,
      total_ttc:  totalTTC,
      due_date:   dueDate,
    }).select().single()

    if (error) throw error
    return NextResponse.json(data, { status: 201 })
  } catch {
    return NextResponse.json({ error: 'Erreur lors de la création' }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 })

  try {
    const { id, action } = await req.json()
    const db = supabaseAdmin()

    if (action === 'markPaid') {
      const { data } = await db.from('invoices').update({ status: 'paid', paid_at: new Date().toISOString() }).eq('id', id).select().single()
      return NextResponse.json(data)
    }

    if (action === 'send') {
      const { data: inv } = await db.from('invoices').update({ status: 'sent' }).eq('id', id).select('*, missions(*, agencies(*))').single()
      if (inv?.missions?.agencies) {
        const ag = inv.missions.agencies as any
        const pdfBytes = await generateInvoicePDF(inv as any, inv.missions as any)
        await sendInvoiceEmail(ag.email, { number: inv.number, missionId: inv.mission_id, totalTTC: inv.total_ttc, dueDate: inv.due_date }, pdfBytes).catch(console.error)
      }
      return NextResponse.json(inv)
    }

    if (action === 'generatePdf') {
      const { data: inv } = await db.from('invoices').select('*, missions(*, agencies(*))').eq('id', id).single()
      if (!inv) return NextResponse.json({ error: 'Non trouvé' }, { status: 404 })
      const pdfBytes = await generateInvoicePDF(inv as any, inv.missions as any)
      return new NextResponse(pdfBytes, { headers: { 'Content-Type': 'application/pdf', 'Content-Disposition': `attachment; filename="${inv.number}.pdf"` } })
    }

    return NextResponse.json({ error: 'Action inconnue' }, { status: 400 })
  } catch {
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 })
  }
}
