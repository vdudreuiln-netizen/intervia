import { auth } from '@clerk/nextjs/server'
import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { sendNewMissionEmail } from '@/lib/emails'
import { generateMissionId } from '@/lib/utils'
import { z } from 'zod'

const CreateMissionSchema = z.object({
  catId:        z.string().min(1),
  categoryLabel:z.string(),
  sub:          z.string().min(1),
  description:  z.string().min(1),
  address:      z.string().min(5),
  contactName:  z.string().optional(),
  contactPhone: z.string().optional(),
  urgent:       z.boolean().default(false),
})

// GET — liste des missions
export async function GET(req: NextRequest) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 })

  try {
    const db = supabaseAdmin()
    const { searchParams } = new URL(req.url)
    const status   = searchParams.get('status')
    const priority = searchParams.get('priority')
    const limit    = parseInt(searchParams.get('limit') ?? '50')

    let query = db.from('missions')
      .select('*, agencies(name, email), categories(name, icon, color), users!technician_id(name)')
      .order('created_at', { ascending: false })
      .limit(limit)

    if (status)   query = query.eq('status',   status)
    if (priority) query = query.eq('priority', priority)

    const { data, error } = await query
    if (error) throw error
    return NextResponse.json(data)
  } catch (err) {
    console.error('GET /api/missions error:', err)
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 })
  }
}

// POST — créer une mission
export async function POST(req: NextRequest) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 })

  try {
    const body   = await req.json()
    const parsed = CreateMissionSchema.safeParse(body)
    if (!parsed.success) return NextResponse.json({ error: 'Données invalides', details: parsed.error }, { status: 400 })

    const data = parsed.data
    const db   = supabaseAdmin()

    // Récupérer l'agence de l'utilisateur
    const { data: userRow } = await db.from('users').select('agency_id, agencies(name, email)').eq('clerk_id', userId).single()

    const missionId = generateMissionId()

    const { data: mission, error } = await db.from('missions').insert({
      id:            missionId,
      agency_id:     userRow?.agency_id,
      subcategory:   data.sub,
      description:   data.description,
      address:       data.address,
      contact_name:  data.contactName,
      contact_phone: data.contactPhone,
      priority:      data.urgent ? 'urgent' : 'normal',
      status:        'Nouveau',
    }).select().single()

    if (error) throw error

    // Notification email (non bloquant)
    if (userRow?.agencies) {
      sendNewMissionEmail(process.env.RESEND_FROM_EMAIL!, {
        id:       missionId,
        agency:   (userRow.agencies as any).name,
        category: data.categoryLabel,
        address:  data.address,
        urgent:   data.urgent,
      }).catch(console.error)
    }

    // Créer notification en base
    await db.from('notifications').insert({
      type:       data.urgent ? 'MISSION_URGENT' : 'NEW_MISSION',
      title:      data.urgent ? '🚨 Mission urgente reçue' : 'Nouvelle mission reçue',
      message:    `${data.categoryLabel} — ${data.address}`,
      mission_id: missionId,
    }).catch(console.error)

    return NextResponse.json(mission, { status: 201 })
  } catch (err) {
    console.error('POST /api/missions error:', err)
    return NextResponse.json({ error: 'Erreur lors de la création' }, { status: 500 })
  }
}
