import { auth } from '@clerk/nextjs/server'
import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { generateQuotePDF } from '@/lib/pdf'
import { sendQuoteEmail } from '@/lib/emails'
import { generateQuoteNumber, calcQuoteTotals } from '@/lib/utils'
import { z } from 'zod'

const QuoteLineSchema = z.object({
  description: z.string(),
  qty:         z.number().positive(),
  unit:        z.string(),
  priceHT:     z.number().min(0),
  tva:         z.number().min(0).max(100),
})

const CreateQuoteSchema = z.object({
  missionId: z.string(),
  lines:     z.array(QuoteLineSchema),
  notes:     z.string().optional(),
  validUntil:z.string().optional(),
})

// GET — devis d'une mission
export async function GET(req: NextRequest) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const missionId = searchParams.get('missionId')

  try {
    const db = supabaseAdmin()
    let query = db.from('quotes').select('*, missions(id, address, agencies(name))').order('created_at', { ascending: false })
    if (missionId) query = query.eq('mission_id', missionId)

    const { data, error } = await query
    if (error) throw error
    return NextResponse.json(data)
  } catch (err) {
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 })
  }
}

// POST — créer un devis
export async function POST(req: NextRequest) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 })

  try {
    const body   = await req.json()
    const parsed = CreateQuoteSchema.safeParse(body)
    if (!parsed.success) return NextResponse.json({ error: 'Données invalides' }, { status: 400 })

    const { missionId, lines, notes, validUntil } = parsed.data
    const { totalHT, totalTVA, totalTTC } = calcQuoteTotals(lines)
    const db     = supabaseAdmin()
    const number = generateQuoteNumber()

    const { data: quote, error } = await db.from('quotes').insert({
      mission_id:  missionId,
      number,
      status:      'draft',
      lines,
      total_ht:    totalHT,
      total_tva:   totalTVA,
      total_ttc:   totalTTC,
      notes,
      valid_until: validUntil,
    }).select().single()

    if (error) throw error
    return NextResponse.json(quote, { status: 201 })
  } catch (err) {
    return NextResponse.json({ error: 'Erreur lors de la création' }, { status: 500 })
  }
}

// PATCH — envoyer / signer le devis
export async function PATCH(req: NextRequest) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 })

  try {
    const { id, action, signature, signatureType } = await req.json()
    const db = supabaseAdmin()

    if (action === 'send') {
      const { data: quote } = await db.from('quotes').update({ status: 'sent' }).eq('id', id).select('*, missions(id, address, agencies(name, email))').single()
      // Email agence
      if (quote?.missions?.agencies) {
        const ag = quote.missions.agencies as any
        await sendQuoteEmail(ag.email, { number: quote.number, missionId: quote.mission_id, totalTTC: quote.total_ttc, agencyName: ag.name }).catch(console.error)
      }
      return NextResponse.json(quote)
    }

    if (action === 'sign') {
      const field = signatureType === 'client' ? 'client_signature' : 'technician_signature'
      const { data: updated } = await db.from('quotes').update({ [field]: signature, signed_at: new Date().toISOString(), status: 'accepted' }).eq('id', id).select().single()
      return NextResponse.json(updated)
    }

    if (action === 'generatePdf') {
      const { data: quote } = await db.from('quotes').select('*, missions(*, agencies(*))').eq('id', id).single()
      if (!quote) return NextResponse.json({ error: 'Non trouvé' }, { status: 404 })
      const pdfBytes = await generateQuotePDF(quote as any, quote.missions as any)
      return new NextResponse(pdfBytes, { headers: { 'Content-Type': 'application/pdf', 'Content-Disposition': `attachment; filename="${quote.number}.pdf"` } })
    }

    return NextResponse.json({ error: 'Action inconnue' }, { status: 400 })
  } catch (err) {
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 })
  }
}
