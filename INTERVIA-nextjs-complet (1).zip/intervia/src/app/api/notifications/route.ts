import { auth } from '@clerk/nextjs/server'
import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

export async function GET(req: NextRequest) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 })

  try {
    const db = supabaseAdmin()
    const { data: userRow } = await db.from('users').select('id').eq('clerk_id', userId).single()
    if (!userRow) return NextResponse.json([])

    const { data, error } = await db.from('notifications')
      .select('*')
      .eq('user_id', userRow.id)
      .order('created_at', { ascending: false })
      .limit(30)

    if (error) throw error
    return NextResponse.json(data)
  } catch {
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 })

  try {
    const { id, markAllRead } = await req.json()
    const db = supabaseAdmin()
    const { data: userRow } = await db.from('users').select('id').eq('clerk_id', userId).single()

    if (markAllRead) {
      await db.from('notifications').update({ read: true }).eq('user_id', userRow?.id)
    } else if (id) {
      await db.from('notifications').update({ read: true }).eq('id', id)
    }

    return NextResponse.json({ success: true })
  } catch {
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 })
  }
}
