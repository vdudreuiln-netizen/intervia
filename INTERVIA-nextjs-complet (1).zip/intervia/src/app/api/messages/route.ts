import { auth } from '@clerk/nextjs/server'
import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

export async function GET(req: NextRequest) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const missionId = searchParams.get('missionId')
  if (!missionId) return NextResponse.json({ error: 'missionId requis' }, { status: 400 })

  try {
    const db = supabaseAdmin()
    const { data, error } = await db.from('messages')
      .select('*, users!sender_id(name, role)')
      .eq('mission_id', missionId)
      .order('created_at', { ascending: true })
    if (error) throw error
    return NextResponse.json(data)
  } catch {
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  const { userId } = auth()
  if (!userId) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 })

  try {
    const { missionId, content, attachmentUrl } = await req.json()
    if (!missionId || !content?.trim()) return NextResponse.json({ error: 'Données manquantes' }, { status: 400 })

    const db = supabaseAdmin()
    const { data: userRow } = await db.from('users').select('id').eq('clerk_id', userId).single()

    const { data, error } = await db.from('messages').insert({
      mission_id:     missionId,
      sender_id:      userRow?.id,
      content:        content.trim(),
      attachment_url: attachmentUrl,
    }).select('*, users!sender_id(name, role)').single()

    if (error) throw error
    return NextResponse.json(data, { status: 201 })
  } catch {
    return NextResponse.json({ error: 'Erreur envoi' }, { status: 500 })
  }
}
