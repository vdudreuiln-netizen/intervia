// ============================================================
// INTERVIA — Constantes de l'application
// ============================================================

export const CATEGORIES = [
  { id: 'plomberie',   icon: '🔧', label: 'Plomberie',     color: '#0EA5E9',
    subs: ['Fuite robinet', 'Canalisation bouchée', 'WC cassé', 'Dégât des eaux', 'Siphon bouché', 'Chasse d\'eau'] },
  { id: 'electricite', icon: '⚡', label: 'Électricité',   color: '#F59E0B',
    subs: ['Panne tableau électrique', 'Prise défectueuse', 'Court-circuit', 'Mise aux normes', 'Éclairage', 'Interrupteur cassé'] },
  { id: 'serrurerie',  icon: '🔑', label: 'Serrurerie',    color: '#8B5CF6',
    subs: ['Porte claquée', 'Serrure cassée', 'Cylindre à changer', 'Ouverture coffre', 'Blindage porte'] },
  { id: 'menuiserie',  icon: '🪚', label: 'Menuiserie',    color: '#A16207',
    subs: ['Porte bloquée', 'Fenêtre cassée', 'Parquet abîmé', 'Volet défectueux', 'Placard cassé'] },
  { id: 'vitrerie',    icon: '🪟', label: 'Vitrerie',      color: '#06B6D4',
    subs: ['Vitre cassée', 'Double vitrage', 'Miroir brisé', 'Verre fenêtre'] },
  { id: 'chauffage',   icon: '🔥', label: 'Chauffage',     color: '#EF4444',
    subs: ['Chaudière en panne', 'Radiateur froid', 'Thermostat défectueux', 'Fuite radiateur', 'Entretien chaudière'] },
  { id: 'clim',        icon: '❄️', label: 'Climatisation', color: '#3B82F6',
    subs: ['Clim en panne', 'Entretien clim', 'Installation clim', 'Bruit anormal'] },
  { id: 'peinture',    icon: '🎨', label: 'Peinture',      color: '#10B981',
    subs: ['Dégât des eaux', 'Peinture intérieure', 'Remise en état', 'Papier peint', 'Plafond abîmé'] },
  { id: 'urgence',     icon: '🚨', label: 'URGENCE',       color: '#EF4444', isUrgent: true,
    subs: ['Inondation', 'Effraction', 'Panne chauffage hiver', 'Dégât majeur', 'Incendie (séquelles)'] },
] as const

export const STATUS_CONFIG: Record<string, { dot: string; bg: string; text: string }> = {
  'Nouveau':      { dot: '#94A3B8', bg: '#F8FAFC', text: '#475569' },
  'En cours':     { dot: '#2563EB', bg: '#EFF6FF', text: '#1D4ED8' },
  'Devis envoyé': { dot: '#D97706', bg: '#FFFBEB', text: '#92400E' },
  'Planifié':     { dot: '#7C3AED', bg: '#F5F3FF', text: '#5B21B6' },
  'Terminé':      { dot: '#059669', bg: '#ECFDF5', text: '#065F46' },
  'Annulé':       { dot: '#DC2626', bg: '#FEF2F2', text: '#991B1B' },
}

export const TVA_RATES = [0, 5.5, 10, 20]

export const DEFAULT_QUOTE_LINES = [
  { description: "Main d'œuvre technicien", qty: 2,  unit: 'h',       priceHT: 65, tva: 20 },
  { description: 'Déplacement',             qty: 1,  unit: 'forfait', priceHT: 25, tva: 20 },
  { description: 'Fournitures',             qty: 1,  unit: 'forfait', priceHT: 0,  tva: 20 },
]

export const NOTIFICATION_TYPES = {
  NEW_MISSION:      { icon: '📋', label: 'Nouvelle mission' },
  MISSION_URGENT:   { icon: '🚨', label: 'Mission urgente' },
  QUOTE_SENT:       { icon: '💰', label: 'Devis envoyé' },
  QUOTE_ACCEPTED:   { icon: '✅', label: 'Devis accepté' },
  QUOTE_REFUSED:    { icon: '❌', label: 'Devis refusé' },
  INVOICE_PAID:     { icon: '💳', label: 'Facture payée' },
  SIGNATURE_DONE:   { icon: '✍️', label: 'Signature effectuée' },
  NEW_MESSAGE:      { icon: '💬', label: 'Nouveau message' },
  STATUS_CHANGED:   { icon: '🔄', label: 'Statut mis à jour' },
} as const

export const COMPANY_INFO = {
  name:    'INTERVIA',
  address: '12 rue de la Paix, 75001 Paris',
  phone:   '01 23 45 67 89',
  email:   'contact@intervia.fr',
  siret:   '123 456 789 00012',
  tva:     'FR12 123456789',
}
