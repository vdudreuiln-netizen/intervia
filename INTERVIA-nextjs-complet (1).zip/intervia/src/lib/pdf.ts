import { PDFDocument, rgb, StandardFonts } from 'pdf-lib'
import { COMPANY_INFO } from './constants'
import { formatDate, formatCurrency } from './utils'
import type { Quote, Invoice, InterventionReport, Mission } from '@/types'

// Couleurs INTERVIA
const NAVY  = rgb(0.051, 0.106, 0.208)
const BLUE  = rgb(0.086, 0.173, 0.353)
const ACCENT= rgb(0.145, 0.388, 0.922)
const GRAY  = rgb(0.392, 0.455, 0.545)
const LIGHT = rgb(0.945, 0.961, 0.980)
const WHITE = rgb(1, 1, 1)
const BLACK = rgb(0, 0, 0)

async function basePDF() {
  const doc  = await PDFDocument.create()
  const page = doc.addPage([595, 842]) // A4
  const bold = await doc.embedFont(StandardFonts.HelveticaBold)
  const reg  = await doc.embedFont(StandardFonts.Helvetica)
  return { doc, page, bold, reg, W: 595, H: 842 }
}

function drawHeader(page: any, bold: any, reg: any, W: number, H: number, subtitle: string) {
  // Bandeau navy
  page.drawRectangle({ x: 0, y: H - 80, width: W, height: 80, color: NAVY })
  // Nom
  page.drawText('INTERVIA', { x: 32, y: H - 36, size: 22, font: bold, color: WHITE })
  page.drawText(subtitle,   { x: 32, y: H - 56, size: 11, font: reg,  color: rgb(1,1,1,.6) })
  // Coordonnées à droite
  const lines = [COMPANY_INFO.address, COMPANY_INFO.phone, COMPANY_INFO.email]
  lines.forEach((l, i) => {
    page.drawText(l, { x: W - 32 - reg.widthOfTextAtSize(l, 9), y: H - 28 - i * 14, size: 9, font: reg, color: rgb(1,1,1,.7) })
  })
}

function drawFooter(page: any, reg: any, W: number, docNumber: string) {
  page.drawRectangle({ x: 0, y: 0, width: W, height: 32, color: LIGHT })
  const left  = `SIRET : ${COMPANY_INFO.siret}  ·  TVA : ${COMPANY_INFO.tva}`
  const right = docNumber
  page.drawText(left,  { x: 32,                                          y: 11, size: 8, font: reg, color: GRAY })
  page.drawText(right, { x: W - 32 - reg.widthOfTextAtSize(right, 8),   y: 11, size: 8, font: reg, color: GRAY })
}

// ── DEVIS ────────────────────────────────────────────────────
export async function generateQuotePDF(quote: Quote, mission: Mission): Promise<Uint8Array> {
  const { doc, page, bold, reg, W, H } = await basePDF()

  drawHeader(page, bold, reg, W, H, `Devis N° ${quote.number}`)

  let y = H - 105

  // Bloc agence / client
  const blockW = (W - 80) / 2
  ;[
    { title: 'ÉMETTEUR', lines: [COMPANY_INFO.name, COMPANY_INFO.address, COMPANY_INFO.email] },
    { title: 'CLIENT',   lines: [mission.agency?.name ?? '—', mission.address] },
  ].forEach((b, i) => {
    const x = 32 + i * (blockW + 16)
    page.drawRectangle({ x, y: y - 72, width: blockW, height: 72, color: LIGHT, borderRadius: 4 })
    page.drawText(b.title, { x: x + 10, y: y - 18, size: 8, font: bold, color: GRAY })
    b.lines.forEach((l, j) => page.drawText(l, { x: x + 10, y: y - 32 - j * 14, size: 10, font: j === 0 ? bold : reg, color: NAVY }))
  })

  y -= 90

  // Infos devis
  page.drawText(`Date : ${formatDate(quote.createdAt)}`, { x: 32, y, size: 10, font: reg, color: GRAY })
  if (quote.validUntil) page.drawText(`Valable jusqu'au : ${formatDate(quote.validUntil)}`, { x: 200, y, size: 10, font: reg, color: GRAY })
  page.drawText(`Ref. mission : ${mission.id}`, { x: W - 200, y, size: 10, font: reg, color: GRAY })

  y -= 28

  // En-tête tableau
  const cols = { desc: 32, qty: 290, unit: 340, pu: 390, tva: 450, total: 500 }
  page.drawRectangle({ x: 28, y: y - 20, width: W - 56, height: 22, color: NAVY })
  ;[['Description', cols.desc], ['Qté', cols.qty], ['Unité', cols.unit], ['PU HT', cols.pu], ['TVA', cols.tva], ['Total HT', cols.total]].forEach(([h, x]) => {
    page.drawText(h as string, { x: x as number + 2, y: y - 14, size: 9, font: bold, color: WHITE })
  })
  y -= 24

  // Lignes
  quote.lines.forEach((line, i) => {
    const bg = i % 2 === 0 ? WHITE : LIGHT
    page.drawRectangle({ x: 28, y: y - 18, width: W - 56, height: 18, color: bg })
    page.drawText(line.description,                    { x: cols.desc, y: y - 13, size: 9, font: reg,  color: BLACK })
    page.drawText(String(line.qty),                    { x: cols.qty,  y: y - 13, size: 9, font: reg,  color: BLACK })
    page.drawText(line.unit,                           { x: cols.unit, y: y - 13, size: 9, font: reg,  color: BLACK })
    page.drawText(formatCurrency(line.priceHT),        { x: cols.pu,   y: y - 13, size: 9, font: reg,  color: BLACK })
    page.drawText(`${line.tva}%`,                      { x: cols.tva,  y: y - 13, size: 9, font: reg,  color: BLACK })
    page.drawText(formatCurrency(line.qty*line.priceHT),{ x: cols.total,y: y - 13, size: 9, font: bold, color: NAVY })
    y -= 20
  })

  y -= 12

  // Totaux
  ;[
    ['Total HT',  formatCurrency(quote.totalHT),  false],
    ['TVA',       formatCurrency(quote.totalTVA), false],
    ['Total TTC', formatCurrency(quote.totalTTC), true ],
  ].forEach(([label, val, isTotal]) => {
    if (isTotal) page.drawRectangle({ x: W - 220, y: y - 20, width: 192, height: 20, color: NAVY })
    page.drawText(label as string, { x: W - 215, y: y - 14, size: isTotal ? 11 : 10, font: isTotal ? bold : reg, color: isTotal ? WHITE : GRAY })
    page.drawText(val as string,   { x: W - 32 - reg.widthOfTextAtSize(val as string, isTotal ? 11 : 10), y: y - 14, size: isTotal ? 11 : 10, font: isTotal ? bold : reg, color: isTotal ? WHITE : NAVY })
    y -= 22
  })

  // Notes
  if (quote.notes) {
    y -= 16
    page.drawText('Notes :', { x: 32, y, size: 10, font: bold, color: NAVY })
    page.drawText(quote.notes, { x: 32, y: y - 14, size: 9, font: reg, color: GRAY, maxWidth: W - 64 })
  }

  // Zone signature
  if (quote.clientSignature) {
    y -= 60
    page.drawRectangle({ x: 32, y: y - 60, width: 180, height: 60, color: LIGHT, borderRadius: 4 })
    page.drawText('Signature client', { x: 32, y: y - 14, size: 9, font: bold, color: GRAY })
    // Embed signature image si disponible
  }

  drawFooter(page, reg, W, quote.number)
  return doc.save()
}

// ── FACTURE ──────────────────────────────────────────────────
export async function generateInvoicePDF(invoice: Invoice, mission: Mission): Promise<Uint8Array> {
  const { doc, page, bold, reg, W, H } = await basePDF()

  drawHeader(page, bold, reg, W, H, `Facture N° ${invoice.number}`)

  let y = H - 105

  ;[
    { title: 'ÉMETTEUR', lines: [COMPANY_INFO.name, COMPANY_INFO.address, COMPANY_INFO.email, `SIRET : ${COMPANY_INFO.siret}`] },
    { title: 'FACTURÉ À', lines: [mission.agency?.name ?? '—', mission.address] },
  ].forEach((b, i) => {
    const blockW = (W - 80) / 2
    const x = 32 + i * (blockW + 16)
    page.drawRectangle({ x, y: y - 80, width: blockW, height: 80, color: LIGHT, borderRadius: 4 })
    page.drawText(b.title, { x: x + 10, y: y - 18, size: 8, font: bold, color: GRAY })
    b.lines.forEach((l, j) => page.drawText(l, { x: x + 10, y: y - 32 - j * 14, size: 10, font: j === 0 ? bold : reg, color: NAVY }))
  })

  y -= 96

  page.drawText(`Date d'émission : ${formatDate(invoice.createdAt)}`, { x: 32, y, size: 10, font: reg, color: GRAY })
  if (invoice.dueDate) page.drawText(`Date d'échéance : ${formatDate(invoice.dueDate)}`, { x: 280, y, size: 10, font: reg, color: GRAY })

  // Statut payée
  if (invoice.status === 'paid') {
    page.drawRectangle({ x: W - 130, y: y - 8, width: 100, height: 22, color: rgb(0.059, 0.725, 0.506) })
    page.drawText('✓ PAYÉE', { x: W - 110, y: y - 2, size: 11, font: bold, color: WHITE })
  }

  y -= 28

  // Tableau identique au devis
  const cols = { desc: 32, qty: 290, unit: 340, pu: 390, tva: 450, total: 500 }
  page.drawRectangle({ x: 28, y: y - 20, width: W - 56, height: 22, color: NAVY })
  ;[['Description', cols.desc], ['Qté', cols.qty], ['Unité', cols.unit], ['PU HT', cols.pu], ['TVA', cols.tva], ['Total HT', cols.total]].forEach(([h, x]) => {
    page.drawText(h as string, { x: x as number + 2, y: y - 14, size: 9, font: bold, color: WHITE })
  })
  y -= 24

  invoice.lines.forEach((line, i) => {
    const bg = i % 2 === 0 ? WHITE : LIGHT
    page.drawRectangle({ x: 28, y: y - 18, width: W - 56, height: 18, color: bg })
    page.drawText(line.description,                     { x: cols.desc, y: y - 13, size: 9, font: reg,  color: BLACK })
    page.drawText(String(line.qty),                     { x: cols.qty,  y: y - 13, size: 9, font: reg,  color: BLACK })
    page.drawText(line.unit,                            { x: cols.unit, y: y - 13, size: 9, font: reg,  color: BLACK })
    page.drawText(formatCurrency(line.priceHT),         { x: cols.pu,   y: y - 13, size: 9, font: reg,  color: BLACK })
    page.drawText(`${line.tva}%`,                       { x: cols.tva,  y: y - 13, size: 9, font: reg,  color: BLACK })
    page.drawText(formatCurrency(line.qty*line.priceHT),{ x: cols.total,y: y - 13, size: 9, font: bold, color: NAVY })
    y -= 20
  })

  y -= 12
  ;[['Total HT', formatCurrency(invoice.totalHT), false], ['TVA', formatCurrency(invoice.totalTVA), false], ['Total TTC', formatCurrency(invoice.totalTTC), true]].forEach(([label, val, isTotal]) => {
    if (isTotal) page.drawRectangle({ x: W - 220, y: y - 20, width: 192, height: 20, color: ACCENT })
    page.drawText(label as string, { x: W - 215, y: y - 14, size: isTotal ? 11 : 10, font: isTotal ? bold : reg, color: isTotal ? WHITE : GRAY })
    page.drawText(val as string,   { x: W - 32 - reg.widthOfTextAtSize(val as string, 10), y: y - 14, size: isTotal ? 11 : 10, font: isTotal ? bold : reg, color: isTotal ? WHITE : NAVY })
    y -= 22
  })

  y -= 30
  page.drawText('Règlement par virement bancaire. IBAN : FR76 1234 5678 9012 3456 7890 123', { x: 32, y, size: 9, font: reg, color: GRAY })

  drawFooter(page, reg, W, invoice.number)
  return doc.save()
}

// ── BON D'INTERVENTION ───────────────────────────────────────
export async function generateReportPDF(report: InterventionReport, mission: Mission): Promise<Uint8Array> {
  const { doc, page, bold, reg, W, H } = await basePDF()
  const docNum = `BON-${mission.id}`

  drawHeader(page, bold, reg, W, H, `Bon d'intervention — ${mission.id}`)

  let y = H - 105

  // Infos mission
  page.drawRectangle({ x: 28, y: y - 90, width: W - 56, height: 90, color: LIGHT, borderRadius: 4 })
  ;[
    ['Mission',    mission.id],
    ['Agence',     mission.agency?.name ?? '—'],
    ['Adresse',    mission.address],
    ['Catégorie',  `${mission.subcategory}`],
    ['Technicien', mission.technician?.name ?? '—'],
    ['Date',       formatDate(report.createdAt)],
  ].forEach(([k, v], i) => {
    const col = i < 3 ? 0 : 1
    const row = i % 3
    page.drawText(`${k} :`, { x: 38 + col * 270, y: y - 20 - row * 22, size: 9,  font: bold, color: GRAY })
    page.drawText(v,         { x: 115 + col * 270, y: y - 20 - row * 22, size: 10, font: reg,  color: NAVY })
  })

  y -= 108

  // Travaux effectués
  page.drawText('TRAVAUX EFFECTUÉS', { x: 32, y, size: 10, font: bold, color: NAVY })
  y -= 14
  page.drawRectangle({ x: 28, y: y - 80, width: W - 56, height: 80, color: LIGHT, borderRadius: 4 })
  page.drawText(report.workDone, { x: 38, y: y - 16, size: 10, font: reg, color: BLACK, maxWidth: W - 80 })
  y -= 96

  // Matériaux
  if (report.materialsUsed) {
    page.drawText('MATÉRIAUX / FOURNITURES', { x: 32, y, size: 10, font: bold, color: NAVY })
    y -= 14
    page.drawRectangle({ x: 28, y: y - 50, width: W - 56, height: 50, color: LIGHT, borderRadius: 4 })
    page.drawText(report.materialsUsed, { x: 38, y: y - 16, size: 10, font: reg, color: BLACK, maxWidth: W - 80 })
    y -= 66
  }

  // Zones signatures
  y -= 16
  page.drawText('SIGNATURES', { x: 32, y, size: 10, font: bold, color: NAVY })
  y -= 14

  const sigW = (W - 80) / 2
  ;[
    { label: 'Signature du client',     name: report.clientName ?? 'Client', sig: report.clientSignature },
    { label: 'Signature du technicien', name: mission.technician?.name ?? 'Technicien', sig: report.technicianSignature },
  ].forEach((s, i) => {
    const x = 32 + i * (sigW + 16)
    page.drawRectangle({ x, y: y - 90, width: sigW, height: 90, color: LIGHT, borderRadius: 4 })
    page.drawText(s.label, { x: x + 8, y: y - 16,  size: 9,  font: bold, color: GRAY })
    page.drawText(s.name,  { x: x + 8, y: y - 30,  size: 10, font: reg,  color: NAVY })
    if (s.sig) {
      page.drawText('✓ Signé électroniquement', { x: x + 8, y: y - 76, size: 9, font: bold, color: rgb(0.059, 0.725, 0.506) })
    } else {
      page.drawRectangle({ x: x + 8, y: y - 80, width: sigW - 16, height: 40, color: WHITE })
    }
  })

  if (report.signedAt) {
    y -= 108
    page.drawText(`Document signé le ${formatDate(report.signedAt)} — Valeur légale probatoire`, { x: 32, y, size: 9, font: reg, color: GRAY })
  }

  drawFooter(page, reg, W, docNum)
  return doc.save()
}
