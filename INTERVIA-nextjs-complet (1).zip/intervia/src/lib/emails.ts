import { Resend } from 'resend'
import { COMPANY_INFO } from './constants'

const resend = new Resend(process.env.RESEND_API_KEY)

const FROM = `${process.env.RESEND_FROM_NAME ?? 'INTERVIA'} <${process.env.RESEND_FROM_EMAIL ?? 'noreply@intervia.fr'}>`

function baseTemplate(title: string, content: string): string {
  return `
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
</head>
<body style="margin:0;padding:0;background:#F1F5F9;font-family:'Segoe UI',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#F1F5F9;padding:32px 16px;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">
        <!-- Header -->
        <tr>
          <td style="background:#0D1B35;border-radius:16px 16px 0 0;padding:28px 32px;">
            <span style="font-size:24px;font-weight:900;color:#fff;letter-spacing:-1px;">
              INTER<span style="color:#3B82F6;">VIA</span>
            </span>
            <p style="color:rgba(255,255,255,.5);font-size:13px;margin:4px 0 0;">${title}</p>
          </td>
        </tr>
        <!-- Body -->
        <tr>
          <td style="background:#fff;padding:32px;border-radius:0 0 16px 16px;border:1px solid #E2E8F0;border-top:none;">
            ${content}
          </td>
        </tr>
        <!-- Footer -->
        <tr>
          <td style="padding:20px 0;text-align:center;">
            <p style="color:#94A3B8;font-size:12px;margin:0;">
              ${COMPANY_INFO.name} · ${COMPANY_INFO.address}<br>
              ${COMPANY_INFO.phone} · ${COMPANY_INFO.email}
            </p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`
}

// ── Email : Nouvelle mission ─────────────────────────────────
export async function sendNewMissionEmail(to: string, mission: {
  id: string; agency: string; category: string; address: string; urgent: boolean
}) {
  const content = `
    ${mission.urgent ? `<div style="background:#FEF2F2;border:1.5px solid #FECDD3;border-radius:10px;padding:14px 18px;margin-bottom:20px;">
      <strong style="color:#EF4444;">🚨 INTERVENTION URGENTE</strong>
      <p style="color:#9F1239;margin:4px 0 0;font-size:13px;">Un technicien doit intervenir dans les 4h.</p>
    </div>` : ''}
    <h2 style="color:#0D1B35;font-size:20px;margin:0 0 16px;">Nouvelle mission reçue</h2>
    <table width="100%" cellpadding="8" style="background:#F8FAFC;border-radius:10px;margin-bottom:24px;">
      <tr><td style="color:#64748B;font-size:13px;width:120px;">Référence</td><td style="color:#0D1B35;font-weight:700;">${mission.id}</td></tr>
      <tr><td style="color:#64748B;font-size:13px;">Agence</td><td style="color:#0D1B35;font-weight:600;">${mission.agency}</td></tr>
      <tr><td style="color:#64748B;font-size:13px;">Catégorie</td><td style="color:#0D1B35;font-weight:600;">${mission.category}</td></tr>
      <tr><td style="color:#64748B;font-size:13px;">Adresse</td><td style="color:#0D1B35;">${mission.address}</td></tr>
    </table>
    <a href="${process.env.NEXT_PUBLIC_APP_URL}/dashboard/missions/${mission.id}"
       style="display:inline-block;background:#2563EB;color:#fff;text-decoration:none;padding:12px 24px;border-radius:10px;font-weight:700;font-size:14px;">
      Voir la mission →
    </a>`

  return resend.emails.send({
    from: FROM, to,
    subject: `${mission.urgent ? '🚨 URGENT — ' : ''}Nouvelle mission ${mission.id} — INTERVIA`,
    html: baseTemplate('Nouvelle mission', content),
  })
}

// ── Email : Devis envoyé ─────────────────────────────────────
export async function sendQuoteEmail(to: string, quote: {
  number: string; missionId: string; totalTTC: number; agencyName: string
}) {
  const content = `
    <h2 style="color:#0D1B35;font-size:20px;margin:0 0 16px;">Votre devis est disponible</h2>
    <p style="color:#64748B;font-size:14px;margin-bottom:20px;">
      Bonjour,<br><br>
      Votre devis <strong>${quote.number}</strong> pour la mission <strong>${quote.missionId}</strong> est prêt.
    </p>
    <div style="background:#EFF6FF;border:1.5px solid #BFDBFE;border-radius:10px;padding:16px 20px;margin-bottom:24px;">
      <div style="color:#64748B;font-size:13px;">Montant total TTC</div>
      <div style="color:#1D4ED8;font-size:28px;font-weight:900;">${new Intl.NumberFormat('fr-FR',{style:'currency',currency:'EUR'}).format(quote.totalTTC)}</div>
    </div>
    <a href="${process.env.NEXT_PUBLIC_APP_URL}/dashboard/quotes/${quote.number}"
       style="display:inline-block;background:#2563EB;color:#fff;text-decoration:none;padding:12px 24px;border-radius:10px;font-weight:700;font-size:14px;">
      Voir et signer le devis →
    </a>`

  return resend.emails.send({
    from: FROM, to,
    subject: `Devis ${quote.number} — ${quote.agencyName} — INTERVIA`,
    html: baseTemplate('Votre devis', content),
  })
}

// ── Email : Facture ──────────────────────────────────────────
export async function sendInvoiceEmail(to: string, inv: {
  number: string; missionId: string; totalTTC: number; dueDate?: string
}, pdfBytes?: Uint8Array) {
  const content = `
    <h2 style="color:#0D1B35;font-size:20px;margin:0 0 16px;">Votre facture</h2>
    <table width="100%" cellpadding="8" style="background:#F8FAFC;border-radius:10px;margin-bottom:24px;">
      <tr><td style="color:#64748B;font-size:13px;width:140px;">N° Facture</td><td style="color:#0D1B35;font-weight:700;">${inv.number}</td></tr>
      <tr><td style="color:#64748B;font-size:13px;">Mission</td><td style="color:#0D1B35;">${inv.missionId}</td></tr>
      <tr><td style="color:#64748B;font-size:13px;">Montant TTC</td><td style="color:#0D1B35;font-weight:700;font-size:16px;">${new Intl.NumberFormat('fr-FR',{style:'currency',currency:'EUR'}).format(inv.totalTTC)}</td></tr>
      ${inv.dueDate ? `<tr><td style="color:#64748B;font-size:13px;">Échéance</td><td style="color:#D97706;font-weight:700;">${inv.dueDate}</td></tr>` : ''}
    </table>
    <p style="color:#64748B;font-size:13px;">La facture en PDF est jointe à cet email.</p>`

  const attachments = pdfBytes ? [{
    filename: `${inv.number}.pdf`,
    content: Buffer.from(pdfBytes).toString('base64'),
  }] : undefined

  return resend.emails.send({
    from: FROM, to,
    subject: `Facture ${inv.number} — INTERVIA`,
    html: baseTemplate('Votre facture', content),
    attachments,
  })
}

// ── Email : Signature effectuée ──────────────────────────────
export async function sendSignatureEmail(to: string, doc: {
  type: 'quote' | 'report'; number: string; missionId: string; signedBy: string
}) {
  const label = doc.type === 'quote' ? 'Devis' : "Bon d'intervention"
  const content = `
    <div style="text-align:center;margin-bottom:24px;">
      <div style="font-size:48px;margin-bottom:8px;">✅</div>
      <h2 style="color:#0D1B35;font-size:20px;margin:0;">${label} signé électroniquement</h2>
    </div>
    <table width="100%" cellpadding="8" style="background:#ECFDF5;border-radius:10px;margin-bottom:24px;">
      <tr><td style="color:#065F46;font-size:13px;width:120px;">Document</td><td style="color:#065F46;font-weight:700;">${doc.number}</td></tr>
      <tr><td style="color:#065F46;font-size:13px;">Mission</td><td style="color:#065F46;">${doc.missionId}</td></tr>
      <tr><td style="color:#065F46;font-size:13px;">Signé par</td><td style="color:#065F46;font-weight:600;">${doc.signedBy}</td></tr>
    </table>`

  return resend.emails.send({
    from: FROM, to,
    subject: `${label} ${doc.number} signé — INTERVIA`,
    html: baseTemplate(`${label} signé`, content),
  })
}
