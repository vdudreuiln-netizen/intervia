import { clsx, type ClassValue } from 'clsx'
import { format, formatDistanceToNow } from 'date-fns'
import { fr } from 'date-fns/locale'

// Fusion de classes Tailwind
export function cn(...inputs: ClassValue[]) {
  return clsx(inputs)
}

// Formatage monétaire
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('fr-FR', {
    style: 'currency',
    currency: 'EUR',
  }).format(amount)
}

// Formatage de date
export function formatDate(date: string | Date): string {
  return format(new Date(date), 'dd/MM/yyyy', { locale: fr })
}

export function formatDateTime(date: string | Date): string {
  return format(new Date(date), "dd/MM/yyyy 'à' HH:mm", { locale: fr })
}

export function timeAgo(date: string | Date): string {
  return formatDistanceToNow(new Date(date), { addSuffix: true, locale: fr })
}

// Génération de numéros de documents
export function generateQuoteNumber(): string {
  const year  = new Date().getFullYear()
  const rand  = Math.floor(Math.random() * 9000) + 1000
  return `DEV-${year}-${rand}`
}

export function generateInvoiceNumber(): string {
  const year  = new Date().getFullYear()
  const rand  = Math.floor(Math.random() * 9000) + 1000
  return `FAC-${year}-${rand}`
}

export function generateMissionId(): string {
  const year  = new Date().getFullYear()
  const rand  = Math.floor(Math.random() * 900) + 100
  return `M-${year}-${rand}`
}

// Calculs de devis
export function calcQuoteTotals(lines: Array<{ qty: number; priceHT: number; tva: number }>) {
  const totalHT  = lines.reduce((acc, l) => acc + l.qty * l.priceHT, 0)
  const totalTVA = lines.reduce((acc, l) => acc + l.qty * l.priceHT * (l.tva / 100), 0)
  const totalTTC = totalHT + totalTVA
  return { totalHT, totalTVA, totalTTC }
}

// Statut couleur
export function getStatusColor(status: string): string {
  const map: Record<string, string> = {
    'Nouveau':      'bg-slate-100 text-slate-600',
    'En cours':     'bg-blue-50 text-blue-700',
    'Devis envoyé': 'bg-amber-50 text-amber-800',
    'Planifié':     'bg-violet-50 text-violet-700',
    'Terminé':      'bg-emerald-50 text-emerald-700',
    'Annulé':       'bg-red-50 text-red-700',
  }
  return map[status] ?? 'bg-gray-100 text-gray-600'
}

// Compression image (client-side)
export async function compressImage(file: File, maxSizeKB = 500): Promise<File> {
  return new Promise((resolve) => {
    const reader = new FileReader()
    reader.readAsDataURL(file)
    reader.onload = (e) => {
      const img = new Image()
      img.src = e.target?.result as string
      img.onload = () => {
        const canvas = document.createElement('canvas')
        let { width, height } = img
        const maxDim = 1920
        if (width > maxDim || height > maxDim) {
          if (width > height) { height = (height * maxDim) / width; width = maxDim }
          else                { width  = (width  * maxDim) / height; height = maxDim }
        }
        canvas.width = width; canvas.height = height
        canvas.getContext('2d')!.drawImage(img, 0, 0, width, height)
        canvas.toBlob((blob) => {
          resolve(new File([blob!], file.name, { type: 'image/jpeg' }))
        }, 'image/jpeg', 0.8)
      }
    }
  })
}

// Truncate text
export function truncate(str: string, n: number): string {
  return str.length > n ? str.substring(0, n - 1) + '…' : str
}
