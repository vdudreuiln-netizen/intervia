// ============================================================
// INTERVIA — Types globaux TypeScript
// ============================================================

export type UserRole = 'agency' | 'artisan' | 'admin'

export type MissionStatus =
  | 'Nouveau'
  | 'En cours'
  | 'Devis envoyé'
  | 'Planifié'
  | 'Terminé'
  | 'Annulé'

export type MissionPriority = 'normal' | 'urgent'

export type QuoteStatus = 'draft' | 'sent' | 'accepted' | 'refused'

export type InvoiceStatus = 'draft' | 'sent' | 'unpaid' | 'paid' | 'overdue'

export interface User {
  id: string
  clerkId: string
  email: string
  name: string
  role: UserRole
  agencyId?: string
  createdAt: string
}

export interface Agency {
  id: string
  name: string
  email?: string
  phone?: string
  address?: string
  logoUrl?: string
  createdAt: string
}

export interface Category {
  id: string
  name: string
  icon: string
  color: string
  isUrgent: boolean
}

export interface Mission {
  id: string
  agencyId: string
  agency?: Agency
  categoryId?: string
  category?: Category
  subcategory: string
  description?: string
  address: string
  contactName?: string
  contactPhone?: string
  priority: MissionPriority
  status: MissionStatus
  technicianId?: string
  technician?: User
  scheduledAt?: string
  createdAt: string
  updatedAt: string
  attachments?: Attachment[]
  quotes?: Quote[]
  messages?: Message[]
}

export interface QuoteLine {
  description: string
  qty: number
  unit: string
  priceHT: number
  tva: number
}

export interface Quote {
  id: string
  missionId: string
  mission?: Mission
  number: string
  status: QuoteStatus
  lines: QuoteLine[]
  totalHT: number
  totalTVA: number
  totalTTC: number
  notes?: string
  validUntil?: string
  clientSignature?: string
  technicianSignature?: string
  signedAt?: string
  createdAt: string
}

export interface Invoice {
  id: string
  missionId: string
  mission?: Mission
  quoteId?: string
  number: string
  status: InvoiceStatus
  lines: QuoteLine[]
  totalHT: number
  totalTVA: number
  totalTTC: number
  dueDate?: string
  paidAt?: string
  createdAt: string
}

export interface InterventionReport {
  id: string
  missionId: string
  workDone: string
  materialsUsed?: string
  startTime?: string
  endTime?: string
  clientName?: string
  clientSignature?: string
  technicianSignature?: string
  signedAt?: string
  pdfUrl?: string
  createdAt: string
}

export interface Attachment {
  id: string
  missionId: string
  url: string
  name: string
  type: 'photo' | 'document'
  uploadedBy?: string
  createdAt: string
}

export interface Notification {
  id: string
  userId: string
  type: string
  title: string
  message?: string
  missionId?: string
  read: boolean
  createdAt: string
}

export interface Message {
  id: string
  missionId: string
  senderId: string
  sender?: User
  content: string
  attachmentUrl?: string
  read: boolean
  createdAt: string
}
