# 🛡️ INTERVIA — Plateforme SaaS de Gestion d'Interventions

> Application web professionnelle pour agences immobilières et services multiservices.

---

## 🚀 Démarrage rapide (5 minutes)

### 1. Copier les variables d'environnement
```bash
cp .env.example .env.local
```
Remplissez `.env.local` avec vos clés (voir section Configuration).

### 2. Installer les dépendances
```bash
npm install
```

### 3. Lancer en développement
```bash
npm run dev
```
Ouvrez http://localhost:3000 ✅

---

## ⚙️ Configuration des services

### 🔐 Clerk (Authentification)
1. Créez un compte sur https://clerk.com
2. Créez une application "INTERVIA"
3. Activez Email + Google comme méthodes de connexion
4. Copiez vos clés dans `.env.local`

### 🗄️ Supabase (Base de données)
1. Créez un projet sur https://supabase.com
2. Allez dans **SQL Editor → New query**
3. Copiez-collez le contenu de `scripts/database.sql`
4. Cliquez **Run**
5. Copiez vos clés dans `.env.local`

### 📧 Resend (Emails)
1. Créez un compte sur https://resend.com
2. Créez une clé API
3. Ajoutez votre domaine d'envoi (ou utilisez le domaine test)
4. Copiez la clé dans `.env.local`

---

## 🚀 Déploiement sur Vercel

### Méthode 1 : Interface Vercel (recommandée)
1. Poussez votre code sur GitHub
2. Connectez-vous sur https://vercel.com
3. Importez votre repository
4. Ajoutez toutes les variables d'environnement
5. Cliquez **Deploy** ✅

### Méthode 2 : CLI
```bash
npm install -g vercel
vercel login
vercel --prod
```

---

## 📁 Structure du projet

```
intervia/
├── src/
│   ├── app/
│   │   ├── layout.tsx              # Layout racine + Clerk
│   │   ├── page.tsx                # Redirection auto
│   │   ├── globals.css             # Styles globaux
│   │   ├── sign-in/               # Page connexion
│   │   ├── sign-up/               # Page inscription
│   │   ├── dashboard/
│   │   │   ├── layout.tsx          # Sidebar + navigation
│   │   │   ├── page.tsx            # Tableau de bord
│   │   │   ├── missions/
│   │   │   │   ├── page.tsx        # Liste des missions
│   │   │   │   └── new/page.tsx    # Tunnel création
│   │   │   ├── calendar/           # Planning
│   │   │   ├── quotes/             # Devis
│   │   │   ├── invoices/           # Factures
│   │   │   └── messages/           # Chat
│   │   └── api/
│   │       ├── missions/route.ts   # API missions
│   │       ├── quotes/route.ts     # API devis
│   │       ├── invoices/route.ts   # API factures
│   │       ├── messages/route.ts   # API messages
│   │       └── notifications/      # API notifications
│   ├── lib/
│   │   ├── supabase.ts             # Client Supabase
│   │   ├── constants.ts            # Données statiques
│   │   ├── utils.ts                # Fonctions utilitaires
│   │   ├── pdf.ts                  # Génération PDF
│   │   └── emails.ts               # Envoi emails
│   ├── types/
│   │   └── index.ts                # Types TypeScript
│   └── middleware.ts               # Protection routes Clerk
├── scripts/
│   └── database.sql                # Script SQL complet
├── .env.example                    # Template variables
├── vercel.json                     # Config déploiement
└── package.json
```

---

## 🎯 Fonctionnalités

| Fonctionnalité           | Statut |
|--------------------------|--------|
| Authentification Clerk   | ✅ |
| Tunnel création mission  | ✅ |
| Gestion des missions     | ✅ |
| Devis avec PDF           | ✅ |
| Factures avec PDF        | ✅ |
| Signature électronique   | ✅ |
| Bon d'intervention       | ✅ |
| Chat interne             | ✅ |
| Notifications email      | ✅ |
| Planning calendrier      | ✅ |
| Upload photos            | ✅ |
| Rôles agence/artisan     | ✅ |
| Base PostgreSQL          | ✅ |
| Déploiement Vercel       | ✅ |

---

## 🛠️ Stack technique

- **Frontend** : Next.js 14 (App Router) + TypeScript + TailwindCSS
- **Auth** : Clerk
- **BDD** : PostgreSQL via Supabase
- **PDF** : pdf-lib
- **Emails** : Resend
- **Déploiement** : Vercel

---

## 📞 Support

Pour toute question, ouvrez une issue GitHub ou contactez contact@intervia.fr.
