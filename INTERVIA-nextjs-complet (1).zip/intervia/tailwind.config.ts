import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        navy:   '#0D1B35',
        blue:   '#162C5A',
        accent: '#2563EB',
        sky:    '#3B82F6',
      },
      fontFamily: {
        sans: ['DM Sans', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        card: '0 1px 3px rgba(0,0,0,.07), 0 4px 16px rgba(0,0,0,.05)',
        modal: '0 30px 80px rgba(0,0,0,.25)',
      },
    },
  },
  plugins: [],
}

export default config
